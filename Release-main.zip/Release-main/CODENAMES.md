This file contains a list of codenames for LTS releases. Codenames for future
releases are subject to change.

* Argon (4.x 2015)
* Boron (6.x 2016)
* Carbon (8.x 2017)
* Dubnium (10.x 2018)
* Erbium (12.x 2019)
* Fermium (14.x 2020)
* Gallium (16.x 2021)
* Hydrogen (18.x 2022)
* Iron (20.x 2023)
* Jod (22.x 2024)
* Krypton (24.x 2025)
* Lithium (26.x 2026)
* Magnesium (28.x 2027)
* Neon (30.x 2028)
* Oxygen (32.x 2029)
* Platinum (34.x 2030)

The release schedule is available as a [JSON](./schedule.json) file.
